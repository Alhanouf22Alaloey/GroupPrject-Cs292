package com.mycompany.thecsworld

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
