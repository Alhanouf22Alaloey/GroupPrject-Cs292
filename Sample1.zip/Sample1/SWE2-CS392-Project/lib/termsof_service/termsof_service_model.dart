import '/flutter_flow/flutter_flow_util.dart';
import 'termsof_service_widget.dart' show TermsofServiceWidget;
import 'package:flutter/material.dart';

class TermsofServiceModel extends FlutterFlowModel<TermsofServiceWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();

  /// Initialization and disposal methods.

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }

  /// Action blocks are added here.

  /// Additional helper methods are added here.
}
